#
# File: __init__.py
#

from project0_py.helpers import *

## top-level submission file


### imports here
import numpy as np
###


def f(a, b):
	'''
	Function for adding two numbers
	Args:
		a (float): first number
		b (float): second number
	Returns:
		c (float): result
	'''

	c = a + b

	return c
